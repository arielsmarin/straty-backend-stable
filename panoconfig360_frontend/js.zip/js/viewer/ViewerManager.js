/**
 * ViewerManager.js
 * Gerenciamento do Marzipano viewer
 * Baseado no panoconfig_frontend que funcionava
 */

import { CreateCameraController, CAMERA_POIS } from "./CameraController.js";
import { TILE_PATTERN } from "../utils/TilePattern.js";

export class ViewerManager {
  constructor(containerId, viewerConfig = {}) {
    this._containerId = containerId;
    this._viewerConfig = viewerConfig;
    this._viewer = null;
    this._view = null;
    this._geometry = null;
    this._cameraController = null;
    this._currentScene = null;
    this._currentBuild = null;
    this._isTransitioning = false;
    this._pendingScene = null;
    this._scenesToDestroy = [];
  }

  get viewer() {
    return this._viewer;
  }

  get view() {
    return this._view;
  }

  /**
   * Inicializa o Marzipano viewer
   */
  initialize() {
    const container = document.getElementById(this._containerId);
    if (!container) {
      throw new Error(`Container não encontrado: ${this._containerId}`);
    }

    if (typeof Marzipano === "undefined") {
      throw new Error(
        "Marzipano não está carregado. Verifique o script no HTML.",
      );
    }

    // Cria o viewer SEM desabilitar scrollZoom
    this._viewer = new Marzipano.Viewer(container, {
      controls: { mouseViewMode: "drag" },
    });

    // Recupera POI salvo
    const savedPoi = localStorage.getItem("pano-camera-poi") || "island";
    const initialPoi = CAMERA_POIS[savedPoi] ||
      CAMERA_POIS.island || { yaw: 0, pitch: 0 };

    // Cria view global - IMPORTANTE: sem limiter inicialmente
    this._view = new Marzipano.RectilinearView({
      yaw: initialPoi.yaw,
      pitch: initialPoi.pitch,
      fov: this._viewerConfig.defaultFov || Math.PI / 2,
    });

    // Cria geometria ÚNICA - IMPORTANTE: { size: cubeSize, tileSize: tileSize }
    const { tileSize = 512, cubeSize = 1024 } = this._viewerConfig;
    this._geometry = new Marzipano.CubeGeometry([
      { size: cubeSize, tileSize: tileSize },
    ]);

    // Inicializa controle de câmera
    this._cameraController = CreateCameraController(this._view);

    console.log("[ViewerManager] Viewer inicializado");
    return this._viewer;
  }

  /**
   * Carrega uma cena com os tiles
   */
  async loadScene(clientId, sceneId, buildString) {
    if (!this._viewer) {
      throw new Error("Viewer não inicializado");
    }

    // Monta URL do tile pattern
    const tileUrl = TILE_PATTERN.getMarzipanoPattern(
      clientId,
      sceneId,
      buildString,
    );
    console.log(`[ViewerManager] Carregando tiles: ${tileUrl}`);

    // Cria source
    const source = Marzipano.ImageUrlSource.fromString(tileUrl);

    // Cria cena usando view e geometry globais
    const scene = this._viewer.createScene({
      source: source,
      geometry: this._geometry,
      view: this._view,
      pinFirstLevel: true,
    });

    if (this._currentScene) {
      const cameraState = this._cameraController.getState();
      this._switchScene(scene);
      this._cameraController.restore(cameraState);
    } else {
      this._switchScene(scene);
    }

    // Faz switch de cena
    this._switchScene(scene);
    this._currentBuild = buildString;
    this._cameraController.restore(cameraState);

    console.log(`[ViewerManager] Cena carregada: ${buildString}`);
    return scene;
  }

  /**   * Atualiza build (troca tiles mantendo a cena)
   */
  async updateBuild(clientId, sceneId, buildString) {
    if (!this._currentScene) {
      console.warn("[ViewerManager] Nenhuma cena ativa para updateBuild");
      return;
    }

    if (this._currentBuild === buildString) {
      console.log("[ViewerManager] Build já aplicada, ignorando");
      return;
    }

    const tileUrl = TILE_PATTERN.getMarzipanoPattern(
      clientId,
      sceneId,
      buildString,
    );

    console.log(`[ViewerManager] Atualizando build: ${tileUrl}`);

    const source = Marzipano.ImageUrlSource.fromString(tileUrl);

    try {
      // 🔑 ponto crítico: troca APENAS o source
      this._currentScene.source().setSource(source);
      this._currentBuild = buildString;
    } catch (e) {
      console.error("[ViewerManager] Erro ao atualizar build:", e);
    }
  }

  /**
   * Atualiza a cena com novos tiles (mantém a view)
   */
  async updateScene(clientId, sceneId, buildString) {
    if (this._currentBuild === buildString) {
      console.log("[ViewerManager] Build já carregada, ignorando");
      return;
    }

    // Carrega nova cena (view é mantida pois é global)
    await this.loadScene(clientId, sceneId, buildString);
    console.log(`[ViewerManager] Cena atualizada: ${buildString}`);
  }

  /**
   * Switch de cena robusto - evita "No such layer in stage"
   */
  _switchScene(nextScene, opts = {}) {
    const transitionDuration = opts.transitionDuration ?? 300;

    // Primeira cena
    if (!this._currentScene) {
      try {
        nextScene.switchTo({ transitionDuration: 0 });
        this._currentScene = nextScene;
      } catch (e) {
        console.error("[ViewerManager] Erro ao exibir cena inicial:", e);
      }
      return;
    }

    // Se já está em transição, enfileira
    if (this._isTransitioning) {
      if (this._pendingScene && this._pendingScene !== nextScene) {
        this._scenesToDestroy.push(this._pendingScene);
      }
      this._pendingScene = nextScene;
      return;
    }

    this._executeTransition(nextScene, transitionDuration);
  }

  _executeTransition(nextScene, transitionDuration) {
    this._isTransitioning = true;
    const prevScene = this._currentScene;
    this._currentScene = nextScene;

    try {
      this._viewer.stopMovement();
      this._viewer.setIdleMovement(null);
    } catch (e) {}

    try {
      nextScene.switchTo({ transitionDuration }, () => {
        this._onTransitionComplete(prevScene, transitionDuration);
      });
    } catch (e) {
      console.error("[ViewerManager] Erro ao fazer switchTo:", e);
      this._isTransitioning = false;
      this._processPendingScene();
    }
  }

  _onTransitionComplete(prevScene, transitionDuration) {
    if (prevScene) {
      const destroyDelay = Math.max(transitionDuration + 500, 800);
      setTimeout(() => {
        this._safeDestroyScene(prevScene);
      }, destroyDelay);
    }

    this._scenesToDestroy.forEach((scene) => {
      setTimeout(() => this._safeDestroyScene(scene), 100);
    });
    this._scenesToDestroy = [];

    this._isTransitioning = false;
    this._processPendingScene();
  }

  _processPendingScene() {
    if (this._pendingScene) {
      const next = this._pendingScene;
      this._pendingScene = null;
      setTimeout(() => {
        this._switchScene(next, { transitionDuration: 300 });
      }, 50);
    }
  }

  _safeDestroyScene(scene) {
    if (!scene) return;
    if (scene === this._currentScene) return;
    if (scene === this._pendingScene) return;

    try {
      scene.destroy();
    } catch (e) {
      if (!e.message?.includes("No such layer")) {
        console.warn("[ViewerManager] Aviso ao destruir cena:", e.message);
      }
    }
  }

  /**
   * Foca a câmera em um ponto de interesse
   */
  focusOn(poiKey) {
    if (this._cameraController) {
      this._cameraController.focusOn(poiKey);
    }
  }

  /**
   * Retorna POIs disponíveis
   */
  getAvailablePOIs() {
    return Object.keys(CAMERA_POIS);
  }

  /**
   * Retorna parâmetros atuais da view
   */
  getViewParams() {
    if (!this._view) return null;
    return {
      yaw: this._view.yaw(),
      pitch: this._view.pitch(),
      fov: this._view.fov(),
    };
  }

  /**
   * Destrói o viewer
   */
  destroy() {
    if (this._viewer) {
      this._viewer.destroy();
      this._viewer = null;
      this._view = null;
      this._geometry = null;
      this._currentScene = null;
      this._cameraController = null;
    }
  }
}
